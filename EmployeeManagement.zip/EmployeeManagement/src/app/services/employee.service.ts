import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Employee } from '../models/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  url="http://localhost:3000/employees";

  constructor(private httpClient: HttpClient) { }

  retreiveEmployeeData(){
    return this.httpClient.get<Employee[]>(this.url);
  }

  retreiveEmployeeById(id: number){
    return this.httpClient.get<Employee>(this.url + "/" + id);
  }

  updateEmployeeData(employee:Employee) {
    if (employee.id == null || employee.id <= 0)
    {
      return this.httpClient.post(this.url, employee);
    }
    else{
      return this.httpClient.put(this.url + "/" + employee.id, employee);
    }
  }

  deleteEmployee(id: number)
  {
    return this.httpClient.delete(this.url + "/" + id);
  }

  addData(dataObj) {

  }
}
