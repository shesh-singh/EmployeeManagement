import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {HomeComponent} from './components/home/home.component';
import {EmployeeComponent} from './components/employee/employee.component';
import {LoginComponent} from './login/login/login.component';
import {AuthGuard} from './helpers/auth.guard';

const routes: Routes = [
  {path: '', component: HomeComponent, pathMatch:'full', canActivate:[AuthGuard]},
  {path: 'home', component: HomeComponent, canActivate:[AuthGuard]},
  {path: 'employees', component: EmployeeComponent, canActivate:[AuthGuard]},
  {path: 'login', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
