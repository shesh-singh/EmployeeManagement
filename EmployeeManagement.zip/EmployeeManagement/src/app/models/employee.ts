export class Employee {
  id:number;
  name:string;
  title:string;
  dept:string;
}
