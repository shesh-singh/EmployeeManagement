import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { Employee } from 'src/app/models/employee';
import { AlertService } from 'src/app/services/alert.service';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-emp-edit',
  templateUrl: './emp-edit.component.html',
  styleUrls: ['./emp-edit.component.css']
})
export class EmpEditComponent implements OnInit {
  @Output() employeeSaveEvent = new EventEmitter<boolean>();

  form:FormGroup

  private _employee: Employee;

    @Input() set employee(value: Employee) {

       this._employee = value;
       this.form.patchValue(this._employee);

    }

    get employee(): Employee {

        return this._employee;

    }

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private employeeService: EmployeeService,
    private alertService: AlertService
  ) {
    this.form = this.formBuilder.group({
      id: new FormControl(''),
      name: new FormControl('', Validators.required),
      title: new FormControl(''),
      dept: new FormControl('')
    });
  }

  ngOnInit(): void {
  }

  onSubmit(){
    //Save to service
    if (this.form.valid)
    {
      let val = this.form.value;
      this.employeeService.updateEmployeeData(val).subscribe((data)=> {
        this.employeeSaveEvent.emit(true);
      });
    }
  }

  cancelSave()
  {
    this.employeeSaveEvent.emit(false);
  }

}
