import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/models/employee';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employeeList: Array<Employee> = [];
  displayedColumns: string[] = ['id', 'name', 'title', 'dept', "actions"];
  currentEmployee:Employee;

  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.retreiveData();
  }

  retreiveData(){
    this.employeeService.retreiveEmployeeData().subscribe((employees)=>{
      this.employeeList = employees;
    });
  }

  saveEmployee(isSave:boolean)
  {
    if (isSave){
      this.retreiveData();
    }
    this.currentEmployee = null;
  }

  addEmployee(){
    this.currentEmployee = {
      id:null,
      name:"",
      dept:"",
      title:""
    }
  }

  editEmployee(emp:Employee){
    this.currentEmployee = emp;
  }

  deleteEmployee(id: number)
  {
    this.employeeService.deleteEmployee(id).subscribe((data)=> {
      this.retreiveData();
    });
  }

}
